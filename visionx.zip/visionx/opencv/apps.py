from django.apps import AppConfig


class OpencvConfig(AppConfig):
    name = 'opencv'
