from django.apps import AppConfig


class LogoConfig(AppConfig):
    name = 'project'
