from django.shortcuts import render

def homeWebpage(request):
    return render(request, 'mainPage.html', {})

# Create your views here.
